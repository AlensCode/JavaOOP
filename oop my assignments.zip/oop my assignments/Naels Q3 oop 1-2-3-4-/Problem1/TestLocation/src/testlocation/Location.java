/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testlocation;

/**
 *
 * @author nael
 */
public class Location {
    private String Block;
    private int Floor;
    public Location(){}
    public Location(String Block, int Floor){ 
        setBlock(Block);
        setFloor(Floor);
    
        }
    
    public void setBlock(String Bloock){ this.Block = Block;
    }
    public void setFloor(int Floor){
    this.Floor= Floor;}
    public int getFloor(){return Floor;}
    public String getBlock(){return Block;}
   public void print(){System.out.printf("the Floor is: %d%n the Block is %s", getFloor(),getBlock());}
}
