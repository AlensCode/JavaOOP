/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coordinatortest;

/**
 *
 * @author nael
 */
public class Coordinator {
    private int Id;
    private String Fname;
    private String LastName;
    public Coordinator(){}
    public Coordinator(int Id,String FName, String LastName){
    setId(Id);
    setFName(FName);
    setLastName(LastName);
        }

    public void setLastName(String LastName) {
       this.LastName= LastName; 
    }

    public void setFName(String FName) {
        this.Fname = FName;
        
    }

    public void setId(int Id) {
        this.Id = Id;
           
    }
    public int getId(){return Id;}
    public String getFname(){return Fname;}
    public String getLastName(){return LastName;}
    public void print(){System.out.printf("the id, first name , last name are: %d%n%s%n%s%n",getId(),getFname(),getLastName());}
    
    
}
