/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coordinatortest;

import java.util.Scanner;

/**
 *
 * @author nael
 */
public class CoordinatorTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Coordinator[] drive = new Coordinator[3];
        drive[0]=  new Coordinator(321,"Accounting","xx2","first Floor");
        drive[1]=  new Coordinator(342,"It","zee","Second Flor");
        drive[2]=  new Coordinator(311,"HR","rolly","third Floor");
    Scanner input = new Scanner(System.in);
        System.out.println("please enter 1 : to show all departments locations , 2 to get the coordinator for a specifc department , 3 to change a location , or 4 to exit");
    int number =input.nextInt();
    for(int i=0;i<drive.length;i++){
    if(number==1){System.out.print(drive[i].getLocation());}
    if (number==2){System.out.printf("%s%s",drive[i].getName(),drive[i].getCoordinator());}
    if (number==3){System.out.print("change location");
          String loc=input.nextLine();
    drive[i].setLocation(loc);
    System.out.println(drive[i].getLocation());}
    if (number==4){System.exit(0);}
    }
    
        // TODO code application logic here
    }
    
}
