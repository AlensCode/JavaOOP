/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coordinatortest;

/**
 *
 * @author nael
 */
public class Coordinator {
    private int Number;
    private String Name;
    private String Coordinator;
    private String Location;
 public Coordinator(int Number, String Name, String Coordinator, String Location)
 {setNumber(Number);
 setName(Name);
 setCoordinator(Coordinator);
 setLocation(Location);
 }

    public void setNumber(int Number) { this.Number=Number;
       
    }

    public void setName(String Name) {this.Name =Name;
        
    }

    public void setCoordinator(String Coordinator) { this.Coordinator = Coordinator;
       
    }

    public void setLocation(String Location) { this.Location = Location;
        
    }
    public int getNumber(){return Number;}
    public String getName(){return Name;}
    public String getCoordinator(){return  Coordinator;}
    public String getLocation(){return Location;}
    public void Dept_count(){System.out.println(getNumber());}
    public void print(){System.out.printf("%d%s_Is Located in: %s Coordinator %s",getNumber(),getName(),getLocation(),getCoordinator());}
    
}
