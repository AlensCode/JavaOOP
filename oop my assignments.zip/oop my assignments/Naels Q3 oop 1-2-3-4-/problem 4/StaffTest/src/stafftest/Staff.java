/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stafftest;

/**
 *
 * @author nael
 */
public class Staff {
    private int ID,rank,Count;
    String Fname,LastName;
    private double BS;
    private String Location;
    
    public Staff (int ID,String Location, int rank,String Fname, String LastName, double BS){
    setID(ID);
    setrank(rank);
    setFname(Fname);
    setLastName(LastName);
    setLocation(Location);
    setBS(BS);}

    public void setID(int ID) { this.ID = ID;
        
    }

    public void setrank(int rank) { this.rank = rank;
        
    }
    public void setLocation(String Location){this.Location=Location;}

    public void setFname(String Fname) { this.Fname =Fname;
        
    }

    public void setLastName(String LastName) {
       this.LastName = LastName;
    }

    public void setBS(double BS) {
        this.BS = BS;
    }
    public int getID(){return ID;}
    public int getrank(){return rank;}
    public String getFname(){return Fname;}
    public String getLastName(){return LastName;}
    public String getLocation(){return Location;}
    public double getBS(){return BS;}
    public void Print(){System.out.printf("%d%slives in%s,and has rank%d%n",getID(),getFname(),getLocation(),getrank());}
    
    public void Calculate_salary(){
    if (rank==1){ double BS1= getBS() - getBS()*0.5;
    setBS(BS1);}
    else if (rank==2){double BS2= getBS() - getBS()*0.7;
    setBS(BS2);}
    else if (rank==3){double BS3= getBS() - getBS()*0.1;
    setBS(BS3);}
    }




} 
    
    

