/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stafftest;

import java.lang.reflect.Array;
import java.util.Arrays;


/**
 *
 * @author nael
 */
public class StaffTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String temp;
        Staff[] employee = new Staff[3];
        employee[0] = new Staff(334,"hamra",1,"zamir","yehya",900.5);
        employee[1] = new Staff(312,"marmchial",2,"farid","teyara",777.3);
        employee[2] = new Staff (212,"zalka",3,"edward","culin",556.4);
        
       
       
           String[] r = new String[3];
           r[0] =employee[0].getFname();
           r[1]=employee[1].getFname();
           r[2]=employee[2].getFname();
           for (int i = 0; i < r.length; i++) 
        {
            for (int j = i + 1; j < r.length; j++) { 
                if (r[i].compareTo(r[j])>0) 
                {
                    temp = r[i];
                    r[i] = r[j];
                    r[j] = temp;
                }
            }
        }
        
        
        System.out.print("Strings in Sorted Order:");
        for (int i = 0; i <= r.length - 1; i++) 
        {
            System.out.print(r[i] + ", ");
        }
        
        for(int i=0;i<employee.length;i++){employee[i].Calculate_salary();
        System.out.println(employee[0].getBS()+employee[1].getBS()+employee[2].getBS());}
        
    }
           
                 
        
       
    }
    

